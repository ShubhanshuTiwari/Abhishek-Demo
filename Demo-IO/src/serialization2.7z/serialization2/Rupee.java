package serialization2;

import serialization2.Currency;

public class Rupee extends Currency
{
public Rupee(int amt)
{
super("Rs",amt);
}
}
