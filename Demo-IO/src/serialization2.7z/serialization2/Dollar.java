package serialization2;

import serialization2.Currency;

public class Dollar extends Currency
{
public Dollar(int amt)
{
super("$",amt);
}
}
